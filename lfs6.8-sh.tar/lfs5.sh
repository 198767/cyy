cd /mnt/lfs/sources
rm -rf binutils-2.21 binutils-build
tar  -jxf binutils-2.21.tar.bz2
cd binutils-2.21
mkdir -v ../binutils-build
cd ../binutils-build
../binutils-2.21/configure \
    --target=$LFS_TGT --prefix=/tools \
    --disable-nls --disable-werror
make
make install
cd /mnt/lfs/sources
rm -rf binutils-2.21 binutils-build
cd /mnt/lfs/sources
rm -rf gcc-4.5.2 gcc-build
tar -xjf gcc-4.5.2.tar.bz2
cd gcc-4.5.2
tar -jxf ../mpfr-3.0.0.tar.bz2
mv -v mpfr-3.0.0 mpfr
tar -jxf ../gmp-5.0.1.tar.bz2
mv -v gmp-5.0.1 gmp
tar -zxf ../mpc-0.8.2.tar.gz
mv -v mpc-0.8.2 mpc
mkdir -v ../gcc-build
cd ../gcc-build
../gcc-4.5.2/configure \
    --target=$LFS_TGT --prefix=/tools \
    --disable-nls --disable-shared --disable-multilib \
    --disable-decimal-float --disable-threads \
    --disable-libmudflap --disable-libssp \
    --disable-libgomp --enable-languages=c \
    --with-gmp-include=$(pwd)/gmp --with-gmp-lib=$(pwd)/gmp/.libs \
    --without-ppl --without-cloog
make 
make install
ln -vs libgcc.a `$LFS_TGT-gcc -print-libgcc-file-name | \
    sed 's/libgcc/&_eh/'`
cd /mnt/lfs/sources
rm -rf gcc-4.5.2 gcc-build
cd /mnt/lfs/sources
tar -xjf linux-2.6.37.tar.bz2
cd linux-2.6.37
make mrproper
make headers_check
make INSTALL_HDR_PATH=dest headers_install
cp -rv dest/include/* /tools/include
cd /mnt/lfs/sources
rm -rf linux-2.6.37 
cd /mnt/lfs/sources
tar -xjf glibc-2.13.tar.bz2
cd glibc-2.13
patch -Np1 -i ../glibc-2.13-gcc_fix-1.patch
mkdir -v ../glibc-build
cd ../glibc-build 
case `uname -m` in
  i?86) echo "CFLAGS += -march=i486 -mtune=native" > configparms ;;
esac
../glibc-2.13/configure --prefix=/tools \
    --host=$LFS_TGT --build=$(../glibc-2.13/scripts/config.guess) \
    --disable-profile --enable-add-ons \
    --enable-kernel=2.6.22.5 --with-headers=/tools/include \
    libc_cv_forced_unwind=yes libc_cv_c_cleanup=yes
make 
make install
cd /mnt/lfs/sources
rm -rf glibc-2.13 glibc-build
