cd /mnt/lfs/sources
package='texinfo-4.13a'
rm -rf $package
tar -xzf $package.tar.gz
cd texinfo-4.13
./configure --prefix=/tools
make
make install
