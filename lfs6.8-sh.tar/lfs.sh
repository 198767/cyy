export LFS=/mnt/lfs

#Next, create the mount point and mount the LFS file system by running:

mkdir -pv $LFS
mount -v -t ext3 /dev/sda1 $LFS

#Replace <xxx> with the designation of the LFS partition.


/sbin/swapon -v /dev/sda2
