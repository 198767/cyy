cd /mnt/lfs/sources
rm -rf  grep-2.7
tar -zxf  grep-2.7.tar.gz
cd grep-2.7
./configure --prefix=/tools \
    --disable-perl-regexp
make
make install
