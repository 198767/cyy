cd /mnt/lfs/sources
rm -rf  gzip-1.4
tar -zxf   gzip-1.4.tar.gz
cd gzip-1.4
./configure --prefix=/tools 
make
make install
