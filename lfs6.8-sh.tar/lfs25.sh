cd /mnt/lfs/sources
package='xz-5.0.1'
rm -rf $package
tar -xjf $package.tar.bz2
cd $package
./configure --prefix=/tools
make
make install
