cd /mnt/lfs/sources
rm -rf findutils-4.4.2
tar -xzf findutils-4.4.2.tar.gz
cd  findutils-4.4.2
./configure --prefix=/tools
make
make install
