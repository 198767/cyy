export LFS=/mnt/lfs
mkdir -v $LFS/sources
chmod -v a+wt $LFS/sources
wget -nc  --tries=2 -i wget-list -P $LFS/sources
