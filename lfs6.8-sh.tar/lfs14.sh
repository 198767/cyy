cd /mnt/lfs/sources
rm -rf gawk-3.1.8
tar -jxf  gawk-3.1.8.tar.bz2
cd gawk-3.1.8
./configure --prefix=/tools
make
make install
