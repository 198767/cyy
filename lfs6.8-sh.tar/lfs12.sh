cd /mnt/lfs/sources
rm -rf  file-5.05
tar -xzf file-5.05.tar.gz
cd file-5.05
./configure --prefix=/tools
make
make install
