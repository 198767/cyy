cd /mnt/lfs/sources
rm -rf diffutils-3.0
tar -xzf diffutils-3.0.tar.gz
cd diffutils-3.0
./configure --prefix=/tools
make
make install
