cd /mnt/lfs/sources
package=tar-1.25
rm -rf $package
tar -jxf $package.tar.bz2
cd $package
./configure --prefix=/tools
make
make install
