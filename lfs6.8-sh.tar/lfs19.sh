cd /mnt/lfs/sources
rm -rf make-3.82
tar -jxf  make-3.82.tar.bz2
cd make-3.82
./configure --prefix=/tools 
make
make install
