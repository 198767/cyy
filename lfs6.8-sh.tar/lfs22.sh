cd /mnt/lfs/sources
rm -rf sed-4.2.1
tar -jxf sed-4.2.1.tar.bz2
cd sed-4.2.1
./configure --prefix=/tools
make
make install
