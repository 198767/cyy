cd /mnt/lfs/sources
rm -rf tcl8.5.9
tar -xzf tcl8.5.9-src.tar.gz
cd tcl8.5.9
cd unix
./configure --prefix=/tools
make
make install
chmod -v u+w /tools/lib/libtcl8.5.so
make install-private-headers
ln -sv tclsh8.5 /tools/bin/tclsh

cd /mnt/lfs/sources
rm -rf expect5.45
tar -xzf expect5.45.tar.gz
cd expect5.45
cp -v configure{,.orig}
sed 's:/usr/local/bin:/bin:' configure.orig > configure
./configure --prefix=/tools --with-tcl=/tools/lib \
  --with-tclinclude=/tools/include
make
make SCRIPTS="" install
cd /mnt/lfs/sources
rm -rf dejagnu-1.4.4
tar -xzf dejagnu-1.4.4.tar.gz
cd dejagnu-1.4.4
patch -Np1 -i ../dejagnu-1.4.4-consolidated-1.patch
./configure --prefix=/tools
make install
cd /mnt/lfs/sources
rm -rf ncurses-5.7
tar -xzf ncurses-5.7.tar.gz
cd ncurses-5.7
./configure --prefix=/tools --with-shared \
    --without-debug --without-ada --enable-overwrite
make
make install
cd /mnt/lfs/sources
rm -rf  bash-4.2
tar -xzf bash-4.2.tar.gz
cd bash-4.2
./configure --prefix=/tools --without-bash-malloc
make
make install
ln -vs bash /tools/bin/sh
cd /mnt/lfs/sources
rm -rf  bzip2-1.0.6
tar -xzf  bzip2-1.0.6.tar.gz
cd  bzip2-1.0.6
make
make PREFIX=/tools install
