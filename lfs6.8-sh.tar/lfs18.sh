cd /mnt/lfs/sources
rm -rf m4-1.4.15
tar -jxf   m4-1.4.15.tar.bz2
cd m4-1.4.15
./configure --prefix=/tools 
make
make install
