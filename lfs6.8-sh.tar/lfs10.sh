cd /mnt/lfs/sources
rm -rf coreutils-8.10
tar -xzf coreutils-8.10.tar.gz
cd coreutils-8.10
./configure --prefix=/tools --enable-install-program=hostname
make
make install
cp -v src/su /tools/bin/su-tools
