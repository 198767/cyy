cd /mnt/lfs/sources
rm -rf patch-2.6.1
tar -jxf  patch-2.6.1.tar.bz2
cd patch-2.6.1
./configure --prefix=/tools 
make
make install
