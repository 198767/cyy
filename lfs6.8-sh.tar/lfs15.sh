cd /mnt/lfs/sources
rm -rf  gettext-0.18.1.1
tar -zxf  gettext-0.18.1.1.tar.gz
cd gettext-0.18.1.1
cd gettext-tools
./configure --prefix=/tools --disable-shared
make -C gnulib-lib
make -C src msgfmt
cp -v src/msgfmt /tools/bin
