/* ch05-catdir.c --- Demonstrate opendir(), readdir(), closedir(). */

#include <stdio.h>		/* for printf() etc. */
#include <errno.h>		/* for errno */
#include <sys/types.h>		/* for system types */
#include <sys/stat.h>
#include <dirent.h>		/* for directory functions */
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

char* cyy_pwd(char *dir);

/* main --- loop over directory arguments */

int main(int argc, char **argv)
{
	puts(cyy_pwd("."));
	return 0;
}

char* cyy_pwd(char *dir)
{
	DIR *dp;
	struct dirent *ent;
	struct stat stat_buf;
	char pdir[9999];
	char fullpath[9999];
	char pwd[9999]="";
	char pwd2[9999]="";
	dev_t dev,ino;
	dev_t pdev,pino;
	
	strcpy(pdir,dir);
	while(1)
	{
		if(lstat(pdir,&stat_buf) !=0)
		{
			fprintf(stderr,"lstat: .: %s\n",strerror(errno));
			return NULL;	
		}
		ino=stat_buf.st_ino;
		dev=stat_buf.st_dev;
		sprintf(pdir,"%s/..",pdir);

		if(lstat(pdir,&stat_buf) !=0)
		{
			fprintf(stderr,"lstat: %s: %s\n",pdir,strerror(errno));
			return NULL;	
		}
		pino=stat_buf.st_ino;
		pdev=stat_buf.st_dev;

		if(ino==pino && dev== pdev) //root
		{
				sprintf(pwd2,"/%s",pwd);
				strcpy(pwd,pwd2);
			return strdup(pwd);
		}


		if ((dp = opendir(pdir)) == NULL) {
			fprintf(stderr, " %s: cannot open for reading: %s\n",
					pdir, strerror(errno));
			return NULL;
		}

		while ((ent = readdir(dp)) != NULL)
		{
			sprintf(fullpath,"%s/%s",pdir,ent->d_name);
			if(lstat(fullpath,&stat_buf) !=0)
			{
				fprintf(stderr,"lstat: %s: %s\n",ent->d_name,strerror(errno));
				return NULL;
			}
			if(stat_buf.st_ino==ino && stat_buf.st_dev==dev)
			{
				if(strlen(pwd)!=0)
					sprintf(pwd2,"%s/%s",ent->d_name,pwd);
				else
					sprintf(pwd2,"%s",ent->d_name);
				strcpy(pwd,pwd2);
				break;
			}
		}
		if (closedir(dp) != 0) {
			fprintf(stderr, "  closedir: %s\n",
					 strerror(errno));
			return NULL;
		}
	}
}
