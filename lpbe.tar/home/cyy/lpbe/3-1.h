#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<errno.h>
struct line
{
	size_t buflen;
	char *buf;
	FILE *fp;
};
