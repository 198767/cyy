#include<stdio.h>
int main(int argc,char** argv)
{
	int i,j;
	int invalid=0;
	int aflag=0,bflag=0,cflag=0,xflag=0;
	char* optarg;
	for(i=1;i<argc;i++)
	{
		if(argv[i][0]=='-')
		{
			for(j=1;argv[i][j];j++)
			{
				if(bflag==1)
				{
					optarg=&(argv[i][j]);
					break;
				}
				if(argv[i][j]=='a')
					aflag=1;
				else if(argv[i][j]=='b')
					bflag=1;
				else if(argv[i][j]=='c')
					cflag=1;
				else
					invalid=argv[i][1];
			}
			
		}
	}	
	
	if(aflag==1)
		puts("accept -a!");
	if(bflag==1)
		printf("accept -b %s!\n",optarg);
	if(cflag==1)
		puts("accept -c!");
	if(xflag==1)
		printf("unknown option -%c\n!",xflag);
	return 0;
}
