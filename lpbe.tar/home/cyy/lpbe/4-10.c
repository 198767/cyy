#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc,char** argv)
{
	long len=0;
	int i;
	extern int errno;
	char* end;
	if(argc<3)
	{
		fprintf(stderr,"Useage: ./a.out filelength file ...!\n");
		return -1;
	}
	errno=0;	
	len=strtol(argv[1],&end,10);
	if(*end || len<0)
	{
		fprintf(stderr,"Invalid newmask!\n");
		return -1;
	}
	if(errno !=0)	
	{
		perror("strtol failed!");
		return -1;
	}
	for(i=2;i<argc;i++)
	{
		if(truncate(argv[i],len) !=0)
		{
			fprintf(stderr,"truncate file %s failed:%s",argv[i],strerror(errno));
			return -1;
		}
	}
	return 0;
}
