#include<stdio.h>
extern char **environ;
int main(int argc,char** argv,char** envp)
{
	puts("-------envp------");
	while(*envp)
		puts(*envp++);
	puts("-------envp------");
	puts("-------environ------");
	while(*environ)
		puts(*environ++);
	puts("-------environ------");

}
