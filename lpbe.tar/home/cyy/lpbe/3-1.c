#include "3-1.h"
int readline(struct line * line)
{
	int c;
	char *p;
	extern int errno;
	int off;
	errno=0;
	p=line->buf;
	while((c=getc(line->fp)) !=EOF)
	{
		if(c=='\n')
		{
			*p='\0';
			break;
		}
		else
		{
			*p=c;
		}
		p++;
		if(p==line->buf+line->buflen)
		{
			off=p-line->buf;
			line->buflen*=2;
			line->buf=realloc(line->buf,line->buflen);
			if(!line->buf)
			{
				fprintf(stderr,"%d out of memory!\n",__LINE__);
				exit(1);
			}
			p=line->buf+off;
		}
		errno=0;
	}
	*p='\0';
	if(errno !=0)
	{
		fprintf(stderr,"%d getc() failed!\n",__LINE__);
		exit(1);
	}


}

