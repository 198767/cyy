#include "3-1.h"
int main(int argc,char** argv)
{
	puts("11111111");
	puts("22222222222222");
	return 0;
}

