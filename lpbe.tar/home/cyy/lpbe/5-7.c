/* ch05-catdir.c --- Demonstrate opendir(), readdir(), closedir(). */

#include <stdio.h>		/* for printf() etc. */
#include <errno.h>		/* for errno */
#include <sys/types.h>		/* for system types */
#include <sys/stat.h>
#include <dirent.h>		/* for directory functions */
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

char* cyy_pwd(char *dir);

/* main --- loop over directory arguments */

int main(int argc, char **argv)
{
	puts(cyy_pwd("."));
	return 0;
}

char* cyy_pwd(char *dir)
{
	DIR *dp;
	struct dirent *ent;
	struct stat stat_buf;
	char pdir[9999];
	char fullpath[9999];
	dev_t dev,ino;
	dev_t pdev,pino;
	char *s1,*s2,*s3;
	if(lstat(dir,&stat_buf) !=0)
	{
		fprintf(stderr,"lstat: .: %s\n",strerror(errno));
		return NULL;	
	}
	ino=stat_buf.st_ino;
	dev=stat_buf.st_dev;
	sprintf(pdir,"%s/..",dir);
	if(lstat(pdir,&stat_buf) !=0)
	{
		fprintf(stderr,"lstat: %s: %s\n",pdir,strerror(errno));
		return NULL;	
	}
	pino=stat_buf.st_ino;
	pdev=stat_buf.st_dev;
	if(ino==pino && dev== pdev) //root
	{
		return strdup("/");
	}
	

	if ((dp = opendir(pdir)) == NULL) {
		fprintf(stderr, " %s: cannot open for reading: %s\n",
				 pdir, strerror(errno));
		return NULL;
	}

	s1=NULL;
	while ((ent = readdir(dp)) != NULL)
	{
		sprintf(fullpath,"%s/%s",pdir,ent->d_name);
		if(lstat(fullpath,&stat_buf) !=0)
		{
			fprintf(stderr,"lstat: %s: %s\n",ent->d_name,strerror(errno));
			return NULL;
		}
		if(stat_buf.st_ino==ino && stat_buf.st_dev==dev)
		{
			s1=strdup(ent->d_name);
			break;
		}
	}
	if (closedir(dp) != 0) {
		fprintf(stderr, " %s: closedir: %s\n",
				 dir, strerror(errno));
		return NULL;
	}
	if(!s1)
	{
		fprintf(stderr, "can't find dirname\n");
		return NULL;
	}
	s2=cyy_pwd(pdir);
	if(!s2)
	{
		fprintf(stderr, "can't find dirname\n");
		return NULL;
	}

	s3=malloc(strlen(s1)+strlen(s2)+10);
	if(!s3)
	{
		fprintf(stderr, "malloc failed\n");
		return NULL;
	}
	if(strcmp(s2,"/")==0)
		sprintf(s3,"/%s",s1);
	else
		sprintf(s3,"%s/%s",s2,s1);
	free(s1);
	free(s2);
	return s3;
}
