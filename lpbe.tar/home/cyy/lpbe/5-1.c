#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>

const char* fmt_mode(mode_t mode);
int main(int argc,char** argv)
{
	extern int errno;
	struct stat stat_buf;
	if(argc!=2)
	{
		fprintf(stderr,"Useage: ./a.out file!\n");
		return -1;

	}
	
	if(stat(argv[1],&stat_buf) !=0)
	{
		fprintf(stderr,"Error: stat failed: %s!\n",strerror(errno));
		return -1;
	}
	puts(fmt_mode(stat_buf.st_mode));
	return 0;
}

const char* fmt_mode(mode_t mode)
{
	static char buf[11];
	memset(buf,'-',10);
	buf[10]='\0';
	if(S_ISDIR(mode)) 
		buf[0]='d';
	else if(S_ISCHR(mode)) 
		buf[0]='c';
	else if(S_ISBLK(mode)) 
		buf[0]='b';
	else if(S_ISREG(mode)) 
		buf[0]='-';
	else if(S_ISFIFO(mode)) 
		buf[0]='p';
	else if(S_ISLNK(mode)) 
		buf[0]='l';
	else if(S_ISSOCK(mode)) 
		buf[0]='s';
	if(mode & S_IRUSR)
		buf[1]='r';
	if(mode & S_IWUSR)
		buf[2]='w';
	if(mode & S_IXUSR)
		buf[3]='x';
	if(mode & S_ISUID)
	{
		if(mode & S_IXUSR)
			buf[3]='s';
		else
			buf[3]='S';
	}
	if(mode & S_IRGRP)
		buf[4]='r';
	if(mode & S_IWGRP)
		buf[5]='w';
	if(mode & S_IXGRP)
		buf[6]='x';
	if(mode & S_ISGID)
	{
		if(mode & S_IXGRP)
			buf[6]='s';
		else
			buf[6]='S';
	}



	if(mode & S_IROTH)
		buf[7]='r';
	if(mode & S_IWOTH)
		buf[8]='w';
	if(mode & S_IXOTH)
		buf[9]='x';
	if(mode & S_ISVTX)
	{
		if(mode & S_IXOTH)
			buf[9]='t';
		else
			buf[9]='T';
	}
	return buf;
}
