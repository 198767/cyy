#include<stdio.h>
#include<string.h>

int _optind=0;
char* _optarg=NULL;
int _optopt=0;
int _opterr=1;
int _getopt(int argc,char *const argv[], const char* _optstring)
{
	static int i=1;
	int j;
	static int k=-1;
	int flag;
	if(k==-1)
	{
		if(i<argc && argv[i][0]=='-' && strcmp(argv[i],"--") !=0)
			k=1;	
	}
	if(k!=-1)
	{
		_optopt=argv[i][k];
		if(argv[i][k+1])
			k++;
		else 
			k=-1;
		flag=0;
		for(j=0;_optstring[j];j++)
		{
			if(_optstring[j]==_optopt && _optopt !=':')
			{	
				flag=1;
				if(_optstring[j+1]==':')
					flag=2;
			}
		}

		if(flag==0)
		{
			if(_opterr && _optstring[0]!=':')
				fprintf(stderr,"%s: invalid _option -- '%c'\n",argv[0],_optopt);
			_optind=i;
			if(k==-1)
				i++;
			return '?';
		}
		else if(flag==1)
		{
			_optind=i;
			if(k==-1)
				i++;
			return _optopt;
		}
		else
		{
			if(k!=-1)
			{
				_optarg=&argv[i][k];
				_optind=i;
				k=-1;
				i++;
				return _optopt;
			}
			else if(i+1<argc &&argv[i+1][0] !='-')
			{
				_optarg=argv[i+1];
				_optind=i+1;
				k=-1;
				i+=2;
				return _optopt;
			}
			else
			{
				if(_opterr && _optstring[0]!=':')
					fprintf(stderr,"%s: _option requires an argument -- '%c'\n",argv[0],_optopt);
				_optind=i;
				k=-1;
				i++;
				if(_optstring[0]!=':')
					return '?';
				else
					return ':';
			}
		}
	}
	else
	{
		if(i<argc && strcmp(argv[i],"--") ==0)
			_optind=i+1;
		else
			_optind=i;
		return -1;
	}
}


int main(int argc,char** argv)
{
	int i;
	int c;
	extern char* _optarg;
	extern int _optind;
	extern int _optopt;
	while((c=_getopt(argc,argv,":ab:cdef"))!=-1)
	{
		switch(c)
		{
			case 'a':
			case 'c':
			case 'd':
			case 'e':
			case 'f':
				printf("find -%c\n",c);
				break;
			case 'b':
				printf("find -b arg:%s\n",_optarg);
				break;
			case ':':
				printf("option %c requires an arg\n",_optopt);
				break;
			case '?':
				printf("invalide option %c\n",_optopt);
				break;
			default:
				puts("should not here");
				
		}
	}
	for(i=_optind;i<argc;i++)
		puts(argv[i]);
	return 0;
}
