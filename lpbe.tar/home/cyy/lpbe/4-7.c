#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>

int main(int argc,char** argv)
{
	long mask=0;
	extern int errno;
	char* end;
	if(argc!=2)
	{
		fprintf(stderr,"Useage: ./a.out  newmask!\n");
		return -1;
	}
	errno=0;	
	mask=strtol(argv[1],&end,8);
	if(*end)
	{
		fprintf(stderr,"Invalid newmask!\n");
		return -1;
	}
	
	if(errno !=0)	
	{
		perror("strtol failed!");
		return -1;
	}
	umask(mask);
	return 0;
}
