/* ch05-catdir.c --- Demonstrate opendir(), readdir(), closedir(). */

#include <stdio.h>		/* for printf() etc. */
#include <errno.h>		/* for errno */
#include <sys/types.h>		/* for system types */
#include <sys/stat.h>
#include <dirent.h>		/* for directory functions */
#include <string.h>
#include <unistd.h>

char *myname;
int process(char *dir);
const char* fmt_mode(mode_t mode);

/* main --- loop over directory arguments */

int main(int argc, char **argv)
{
	int i;
	int errs = 0;

	myname = argv[0];

	if (argc == 1)
		errs = process(".");	/* default to current directory */
	else
		for (i = 1; i < argc; i++)
			errs += process(argv[i]);

	return (errs != 0);
}

/*
 * process --- do something with the directory, in this case,
 *             print inode/name pairs on standard output.
 *             Returns 0 if all ok, 1 otherwise.
 */

int
process(char *dir)
{
	DIR *dp;
	struct dirent *ent;
	struct stat stat_buf;
	char name[100];
	char fullpath[9999];
	int c;
	if ((dp = opendir(dir)) == NULL) {
		fprintf(stderr, "%s: %s: cannot open for reading: %s\n",
				myname, dir, strerror(errno));
		return 1;
	}

	errno = 0;
	while ((ent = readdir(dp)) != NULL)
	{
		sprintf(fullpath,"%s/%s",dir,ent->d_name);
		if(lstat(fullpath,&stat_buf) !=0)
		{
			fprintf(stderr,"stat: %s: %s\n",ent->d_name,strerror(errno));
			return 1;
		}
		if(S_ISLNK(stat_buf.st_mode)) 
		{
			c=readlink(ent->d_name,name,100);
			if(c!=stat_buf.st_size)
			{
				fprintf(stderr,"readlink: %s: %s\n",ent->d_name,strerror(errno));
				return 1;
			}
			name[c]='\0';
			printf("%8ld %s %8d %s->%s \n", ent->d_ino,fmt_mode(stat_buf.st_mode), stat_buf.st_nlink,name,ent->d_name);
		
		}
		else
			printf("%8ld %s %8d %s \n", ent->d_ino,fmt_mode(stat_buf.st_mode), stat_buf.st_nlink,ent->d_name);
	}
	if (errno != 0) {
		fprintf(stderr, "%s: %s: reading directory entries: %s\n",
				myname, dir, strerror(errno));
		return 1;
	}

	if (closedir(dp) != 0) {
		fprintf(stderr, "%s: %s: closedir: %s\n",
				myname, dir, strerror(errno));
		return 1;
	}

	return 0;
}
const char* fmt_mode(mode_t mode)
{
	static char buf[11];
	memset(buf,'-',10);
	buf[10]='\0';
	if(S_ISDIR(mode)) 
		buf[0]='d';
	else if(S_ISCHR(mode)) 
		buf[0]='c';
	else if(S_ISBLK(mode)) 
		buf[0]='b';
	else if(S_ISREG(mode)) 
		buf[0]='-';
	else if(S_ISFIFO(mode)) 
		buf[0]='p';
	else if(S_ISLNK(mode)) 
		buf[0]='l';
	else if(S_ISSOCK(mode)) 
		buf[0]='s';
	if(mode & S_IRUSR)
		buf[1]='r';
	if(mode & S_IWUSR)
		buf[2]='w';
	if(mode & S_IXUSR)
		buf[3]='x';
	if(mode & S_ISUID)
	{
		if(mode & S_IXUSR)
			buf[3]='s';
		else
			buf[3]='S';
	}
	if(mode & S_IRGRP)
		buf[4]='r';
	if(mode & S_IWGRP)
		buf[5]='w';
	if(mode & S_IXGRP)
		buf[6]='x';
	if(mode & S_ISGID)
	{
		if(mode & S_IXGRP)
			buf[6]='s';
		else
			buf[6]='S';
	}



	if(mode & S_IROTH)
		buf[7]='r';
	if(mode & S_IWOTH)
		buf[8]='w';
	if(mode & S_IXOTH)
		buf[9]='x';
	if(mode & S_ISVTX)
	{
		if(mode & S_IXOTH)
			buf[9]='t';
		else
			buf[9]='T';
	}
	return buf;
}
