#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

void _perror(const char *s)
{
	extern int errno;
	fprintf(stderr,"%s:%s\n",s,strerror(errno));
	return;
}
int main(int argc,char** argv)
{
	int fd1,fd2;
	char buf[BUFSIZ];
	int rc,wc;
	if(argc!=3)
	{
		fprintf(stderr,"Useage: ./a.out file1 file2!\n");
		return -1;

	}

	if(strcmp(argv[1],argv[2])==0)
	{
		fprintf(stderr,"file1 and file2 can not be same!");
		return -1;
	}

	fd1=open(argv[1],O_RDONLY);
	if(fd1<0)
	{
		_perror("can not open file1!");
		return -1;
	}
	fd2=open(argv[2],O_WRONLY|O_CREAT|O_TRUNC,0666);
	if(fd1<0)
	{
		_perror("can not open file2!");
		return -1;
	}
	while((rc=read(fd1,buf,sizeof buf)) >0)
	{
		wc=write(fd2,buf,rc);
		if(wc !=rc)
		{
			perror("write error!");
			return -1;
		}
	}
	if(rc <0)
	{
		_perror("read error!");
		return -1;
	}
	close(fd1);
	close(fd2);
	return 0;
}


