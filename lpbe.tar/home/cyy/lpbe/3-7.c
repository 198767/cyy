#include "3-1.h"
int main(int argc,char** argv)
{
	struct line l;
	l.buflen=2;
	l.buf=(char*)malloc(l.buflen);
	l.fp=stdin;
	while(readline(&l) !=-1)
		printf("(%d)%s",l.buflen,l.buf);
}

int readline(struct line * line)
{
	int c;
	char *p;
	extern int errno;
	int off;
	errno=0;
	p=line->buf;
	*p='\0';
	while(fgets(p,line->buf+line->buflen-p,line->fp) !=NULL)
	{
		p+=strlen(p);
		if(p[-1]=='\n')
			break;
		if(p==line->buf+line->buflen-1)
		{
			off=p-line->buf;
			line->buflen*=2;
			line->buf=realloc(line->buf,line->buflen);
			if(!line->buf)
			{
				fprintf(stderr,"%d out of memory!\n",__LINE__);
				exit(1);
			}
			p=line->buf+off;
		}
		else
			break;
		errno=0;
	}
	if(errno !=0)
	{
		fprintf(stderr,"%d getc() failed!\n",__LINE__);
		exit(1);
	}
	return 0;
}

