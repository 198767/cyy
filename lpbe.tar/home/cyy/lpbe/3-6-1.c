#include "3-1.h"
int main(int argc,char** argv)
{
	struct line l;
	l.buflen=1;
	l.buf=(char*)malloc(l.buflen);
	l.fp=stdin;
	readline(&l);
	puts(l.buf);
	return 0;
}

